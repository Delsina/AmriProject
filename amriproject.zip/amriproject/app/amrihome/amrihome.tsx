'use client';
import type { NextPage } from "next";
import Image from 'next/image';



const Amrihome: NextPage = () => {
  return (
    <>
  
    <div className="container font-bold text-7xl break-words"></div>
    
    </>
  )
}

export default Amrihome