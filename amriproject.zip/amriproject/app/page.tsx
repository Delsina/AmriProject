'use client';

import Image from "next/image";
import { Button } from "@material-tailwind/react";
import Amrihome from './amrihome/amrihome';
import Amriheader from "./componenets/amriheader";
import Homebg from "./componenets/homebg";
import Reservar from "./componenets/reservar";
import Paracontar from "./componenets/paracontar";
import Habitaciones from "./componenets/Habitaciones";
import Footer from "./componenets/footer";




export default function Home() {
  return (
   <>
   {/* <div className="container mx-auto">
   <h1 className="text-deep-orange-600">hello</h1>
   <Button>Button</Button>
   </div> */}
   <Homebg/>
   <Amriheader/>
   <Reservar/>
   <Paracontar/>
   <Habitaciones/>
   <Footer/>
 <Amrihome/>
 
 
   </>
  );
}
