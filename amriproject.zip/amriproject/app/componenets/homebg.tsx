import type { NextPage } from "next";
import bg from '../../public/image 1.png'
import Image from 'next/image';

const Homebg: NextPage = () => {
  return (
    <>
      <div className="flex flex-col items-center justify-between ">
      <div className="relative w-full">
        <div className="absolute -z-10 w-full">
        <Image
      src={bg}
      alt="Picture of the author"
      className="w-full"
      width={1920}
      height={840}
    />
        </div>
      </div>
    </div>
    </>
  )
}

export default Homebg