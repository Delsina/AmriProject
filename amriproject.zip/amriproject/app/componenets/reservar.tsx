import type { NextPage } from "next";
import Image from "next/image";
import line from "../../public/Line 10.png";
import { MdOutlineCalendarToday } from "react-icons/md";
import { Button } from "@material-tailwind/react";
import { FiSearch } from "react-icons/fi";
import beach from "../../public/beach.png";
import tropica from "../../public/tropica.png";
import { LuUsers } from "react-icons/lu";
const Reservar: NextPage = () => {
  return (
    <>
      <div className="mt-[700px] container mx-auto">
        {/* <div className="grid grid-cols-4 gap-2 place-items-center pb-36"> */}
        <div className="flex">
          <div className="flex items-center gap-4 w-full">
            <div className="iconcolor text-2xl grow-0">
              <MdOutlineCalendarToday />
            </div>
            <div className="grow">
              <div className="text-gray-500">Fecha entrada</div>
              <div className="font-semibold">10 Junio 2021</div>
            </div>
          </div>
          <div className="flex items-center w-full gap-4">
            <div className="iconcolor text-2xl ">
              <MdOutlineCalendarToday />
            </div>
            <div className="grow">
              <div className="text-gray-500"> Fecha salida</div>
              <div className="font-semibold">15 Junio 2021</div>
            </div>
            
          </div>
          <div className="flex items-center w-full gap-4">
            <div className="iconcolor text-2xl ">
            <LuUsers />
            </div>
            <div>
              <div className="text-gray-500 ">Cuartos para</div>
              <div className="font-semibold">3 personas</div>
            </div>
          </div>
          <div>
            <Button className="rounded-full buttoncolor flex items-center capitalize gap-2 w-[210px] text-base">
              <FiSearch size={25} />
              Reserver ahora
            </Button>
          </div>
          </div> <br /> <br /> <br />
          <hr />
          
        {/* </div> */}
        <div className="text-center font-extrabold text-4xl pt-24">
          ¡Disfruta con nosotros!{" "}
        </div>
        <div className="text-center pb-16 text-gray-600 mt-5">Realizamos todo tipo de eventos </div>
        <div className="grid grid-cols-3 gap-2 items-center">
          <div className="col-span-2">
            <Image
              src={beach}
              alt="Picture of the author"
              className="w-full"
              width={744}
              height={361}
            />
          </div>
          <div className="ps-10">
            <div className="iconcolor text-sm">en <b>Playa Noreste</b></div>
            <div className="text-3xl font-bold py-5">Tomorrowland Beach</div>
            <div className="text-sm text-gray-600 leading-1">
              Breve descripción del evento que puede ocupara hasta 3 líneas de
              texto.
            </div>
            <div className="flex items-center iconcolor text-sm py-2">
              <MdOutlineCalendarToday />
             <b>10 Jun 2024</b>  • por 3 días
            </div>
            <div>
              <Button className="rounded-full buttoncolor capitalize mt-14 text-base">
                Me interesa
              </Button>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 items-center mt-36">
          
          <div className="ps-10">
            <div className="iconcolor text-sm">en Playa Sur</div>
            <div className="text-3xl font-bold py-5">World Tropical</div>
            <div className="text-sm text-gray-600 leading-1">
              Breve descripción del evento que puede ocupara hasta 3 líneas de
              texto.
            </div>
            <div className="flex items-center iconcolor text-sm py-2">
              <MdOutlineCalendarToday />
              <b>10 Sep 2024
                </b> • por 1 semana
            </div>
            <div>
              <Button className="rounded-full buttoncolor capitalize mt-14 text-base">
                Me interesa
              </Button>
            </div>
          </div>
          <div className="col-span-2">
            <Image
              src={tropica}
              alt="Picture of the author"
              className="w-full"
              width={744}
              height={361}
            />
          </div>
        </div>
       
      </div>
    </>
  );
};

export default Reservar;
