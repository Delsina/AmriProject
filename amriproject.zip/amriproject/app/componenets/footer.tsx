import type { NextPage } from "next";
import { MdOutlineCalendarToday } from "react-icons/md";
import { RiFacebookFill } from "react-icons/ri";
import { FaInstagram } from "react-icons/fa6";
import { FaTwitter } from "react-icons/fa";


const Footer: NextPage = () => {
  return (
    <>
      <div className="container mx-auto">
        <div className="flex justify-between">
          <div className="grid gap-2">
            <div className="text-4xl font-serif mt-44  text-b">CayoBeach</div>
            <div className="text-gray-600 ">Descripción del hotel. Detalles que los <br /> hagan especial</div>
          </div>
          <div className="flex gap-32">
            <div className="  mt-44  ">
              <div>Habitaciones</div>
              <div>Servicios</div>
              <div>Eventos</div>
            </div>
            <div className="  mt-44  ">
              <div>Habitaciones</div>
              <div>Servicios</div>
              <div>Eventos</div>
            </div>
            <div className="  mt-44  ">
              <div>Habitaciones</div>
              <div>Servicios</div>
              <div>Eventos</div>
            </div>
          </div>
          
        </div>
        <div className="flex justify-between">
        <div className="text-sm mt-20 mb-20 text-gray-600">© Logo Hotel 2023. Derechos reservados</div>
          <div>
            <div className="flex justify-items-end gap-10">
                
                <div  className="text-sm mt-20 mb-20 text-gray-600">Encuentranos en:</div>
                <div className="flex items-center gap-2 text-gray-600 text-xl ml-0 ">
                <RiFacebookFill />
                <FaInstagram />
                <FaTwitter />
                </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
