import type { NextPage } from "next";
import una from "../../public/una.png";
import Image from "next/image";
import { Button } from "@material-tailwind/react";

const Paracontar: NextPage = () => {
  return (
    <>
      <div className="relative mt-24">
        <div>
          <Image
            src={una}
            alt="Picture of the author"
            className="w-full h-full"
            width={1920}
            height={290}
          />
        </div>
        <div className="absolute top-10 right-[30%] text-center">
          <div className="text-4xl text-white font-bold ">Una super experiencia para contar</div>
          <div><Button  color="white" className="rounded-full iconcolor capitalize mt-6 text-md">
          Reservar ahora
              </Button></div>
        </div>
      </div>
    </>
  );
};

export default Paracontar;
