"use client";
import type { NextPage } from "next";
import Link from "next/link";
import { IconButton } from "@material-tailwind/react";
// import { Option } from "@material-tailwind/react";
import { FiSearch } from "react-icons/fi";
// import Select from "react-select";
import { Select, Option } from "@material-tailwind/react";

const options = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];

const Amriheader: NextPage = () => {
  return (
    <>
      <div className="container mx-auto py-5">
        <div className="flex justify-between items-center ">
          <div>
            {" "}
            <h1 className="logotext text-4xl text-white">CayoBeach</h1>
          </div>
          <div>
            <div className="flex justify-between items-center gap-12 font-medium text-xl text-gray-200">
              <Link href="/Home" className="underline">Home</Link>
              <Link href="/Habitaciones">Habitaciones</Link>
              <Link href="/Servicios">Servicios</Link>
              <Link href="/Sobre nosotros">Sobre nosotros</Link>
              <Link href="/Contacto">Contacto</Link>
            </div>
          </div>
          <div className="flex justify-between items-center gap-5  ">
            <div>
              <IconButton color="white" variant="text">
                <FiSearch size={25} />
              </IconButton>
            </div>

            {/* <div>
              <Select options={options} className="bg-black" />
            </div> */}
          
            <Select label="Español" variant="standard" >
        <Option>Material Tailwind HTML</Option>
        <Option>Material Tailwind React</Option>
        <Option>Material Tailwind Vue</Option>
        <Option>Material Tailwind Angular</Option>
        <Option>Material Tailwind Svelte</Option>
      </Select>
      
          </div>
        </div>
      </div>
    </>
  );
};

export default Amriheader;
