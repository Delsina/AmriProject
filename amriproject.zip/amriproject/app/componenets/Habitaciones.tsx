import type { NextPage } from "next";
import Carousel from "react-multi-carousel";
import Image from "next/image";
import room1 from "../../public/room1.png";
import room2 from "../../public/room2.png";
import room3 from "../../public/room3.png";

import "react-multi-carousel/lib/styles.css";
const responsive = {
  superLargeDesktop: {
    // the naming can be any, depends on you.
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const Habitaciones: NextPage = () => {
  return (
    <>
      <div className="text-center font-extrabold text-4xl py-3 mt-16">
        Habitaciones de lujo
      </div>
      <div className="text-center pb-16 text-gray-600">
        Vea todo nuestro catálogo de habitaciones{" "}
      </div>
      <div className="container mx-auto">

        <Carousel responsive={responsive}>
        
          <div className="px-5">
            <Image
              src={room1}
              alt="Picture of the author"
              className="w-full"
              width={310}
              height={240}
            />
            <div className="grid justify-start p-3 ">
            <div className="font-bold text-2xl " >Wilderness Club at Big Ceddar</div>
            <div className="text-gray-500" >2 Baños </div>
            <div className="pt-4 iconcolor"><b className="text-2xl">$816
              </b> /3 night</div>
              </div>
          </div>
          <div className="px-5">
            <Image
              src={room2}
              alt="Picture of the author"
              className="w-full"
              width={310}
              height={240}
            />
            <div className="grid justify-start p-3 ">
            <div className="font-bold text-2xl " >Wilderness Club at Big Ceddar</div>
            <div className="text-gray-500">1 Baño con jacujacuzzi  </div>
            <div className="pt-4 iconcolor"><b className="text-2xl">$2016
              </b> /6 night</div>
              </div>
          </div>
          <div className="px-5">
            <Image
              src={room3}
              alt="Picture of the author"
              className="w-full"
              width={310}
              height={240}
            />
            <div className="grid justify-start p-3 ">
            <div className="font-bold text-2xl " >Wilderness Club at Big Ceddar</div>
            <div className="text-gray-500"> Habitación matrimonial </div>
            <div className="pt-4 iconcolor"><b className="text-2xl">$1024
              </b> /8 night</div>
              </div>
          </div>
          <div className="px-5">
            <Image
              src={room1}
              alt="Picture of the author"
              className="w-full"
              width={310}
              height={240}
            />
            <div className="grid justify-start p-3 ">
            <div className="font-bold text-2xl " >Wilderness Club at Big Ceddar</div>
            <div className="text-gray-500" >2 Baños </div>
            <div className="pt-4 iconcolor"><b className="text-2xl">$816
              </b> /3 night</div>
              </div>
          </div>
          {/* </div> */}
        </Carousel>
      </div>
    </>
  );
};

export default Habitaciones;
